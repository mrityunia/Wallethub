package com.wallethub.common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Base {
	protected WebDriver webDriver;
	public WebElement getWebelement() {
		return webElement;
	}
	public void setWebelement(WebElement webelement) {
		this.webElement = webelement;
	}
	public WebDriver getWebDriver() {
		return webDriver;
	}
	public void setWebDriver(WebDriver webDriver) {
		this.webDriver = webDriver;
	}
	protected WebElement webElement;

	protected Properties flipkartSignUpIn;
	protected Properties walethubuser;

	public Base(WebDriver webDriver){
		setWebDriver(webDriver);
		initilize();
		
	}
	public void initilize(){
		flipkartSignUpIn = new Properties();
		walethubuser= new Properties();
		try {
			
			flipkartSignUpIn.load(new FileInputStream(System.getProperty("user.dir").concat("/src/resource/facbook.properties")));			
				
			walethubuser.load(new FileInputStream(System.getProperty("user.dir").concat("/src/resource/wallethub.properties")));	
		
		
		
		
		
		
		} catch (FileNotFoundException e) {
			System.out.println("Error occured in initilize method");
			System.out.println(e.getMessage());
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error occured in initilize method");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
	}

///////////////////////////////////////////////////////
	
	public  void SwitchWindow() {
		for (String windowName : webDriver.getWindowHandles()) {
			webDriver.switchTo().window(windowName);
		}
	}
	

}
