package com.wallethub.common;

public interface Constraints {
	public  static  final String IE_BROWSER ="ieExplorer";
	public  static final String CHROME_BROWSER ="chrome";
	public  static  final String FF_BROWSER ="fireFox";
	public  static  final String PAGE_MISSING ="page is missing";	

}
