package com.wallethub.common;

import java.awt.Desktop;
import java.io.File;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;


import com.relevantcodes.extentreports.ExtentReports;


public class StartDriver {
	 Logger  log = Logger.getLogger(StartDriver.class); 
	protected static Properties config;	
	protected WebDriver webDriver;
	protected WebElement webelement;
	private DriverFactory factory;
	public static ExtentReports report;
	
	public StartDriver() {
		
		
		 
	}
	@BeforeSuite
	public void intilizeReport(){
		Configuration cnfg = new Configuration();
		cnfg.intilizeProjectConfigProprty();
		report = new ExtentReports (Configuration.reportLocation,true);
		
	}
	
	@BeforeClass
	@Parameters("browsername")
	public WebDriver intilizeDriver(String browsername){
		log.info("Your URL is  "+browsername);
		factory= new DriverFactory();
		webDriver= factory.getDriver(browsername);
		log.info("Web Driver is initiaated ");
	return webDriver;
	}
	
	@AfterClass
	public void quiteDriver() 
	{	
		try{
		
			webDriver.close();
			webDriver.quit();
			log.info("All Browser are closed ");
			
			
		}
		catch(Exception E){
			
			log.error("Some exception occured at -->>quiteDriver methods"+E.getMessage() );
			
		}
		}
	@AfterSuite
	public void endReport(){
		try{
			 Desktop desktop = Desktop.getDesktop();
		Configuration.Exreport.flush();
		File loggerlocation= new File (Configuration.loggerlocation);
		  if(loggerlocation.exists()) desktop.open(loggerlocation);
		 File filereport=new File (Configuration.ReportLocationfinal);
	        if(filereport.exists()) desktop.open(filereport);
		}
		catch(Exception e)
		{
			System.out.println("Some error occured at endReport methods");
		}
		}
	
}
