package com.wallethub.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
public class Configuration {
	 Logger  log = Logger.getLogger(Configuration.class); 
	public static String IE_browseLocation;
	public static String FF_browseLocation;
	public static String Chrome_browserLocation;
	public static String reportLocation;
	public static String testCaesSheetLocation;
	public static String loggerlocation;
	public static ExtentTest test;
	public static String ScreenShots;
    private static Properties prop;
    public static  ExtentReports Exreport;
	public  static ExtentTest Test;
	public static String ReportLocationfinal;
    
    public Configuration(){
    	try {
    		prop = new Properties();
    		prop.load(new FileInputStream(System.getProperty("user.dir").concat("\\src\\report\\configuration.properties")));
		
    	
    	} catch (FileNotFoundException e) {
		
			System.out.println("configurationFile is not found"+e.getMessage());
			
		} catch (Exception e) {
				
			System.out.println("Some error occured at configuration constructer");
    	
    }
	
    }
    
    public  void intilizeProjectConfigProprty () {
		try {
		Chrome_browserLocation=prop.getProperty("chrome_driver");
		IE_browseLocation=prop.getProperty("iE_Driver");
		FF_browseLocation=prop.getProperty("fireFox");
		testCaesSheetLocation=prop.getProperty("Test_Case_Sheet");
		reportLocation=prop.getProperty("report_location");
		ScreenShots=prop.getProperty("ScreenShotsStorageLocation");
		loggerlocation=prop.getProperty("loggerlocation");
		loggerIntilization();
		reportInitilazation();
		} catch (Exception e) {
			
			System.out.println("Some error occured at intilizeProjectConfigProprty"+e.getMessage());
		}
		
	
	}
    public  void loggerIntilization() {
    			 try {
    				 Properties props = new Properties();
    				 props.load(new FileInputStream((System.getProperty("user.dir").concat("/src/report/logger.properties"))));
    	 
    				File logfile=new File (loggerlocation);
    				 if(logfile.exists()) {
    					 
    				 logfile.delete();
    			 }		 
    					 if(logfile.createNewFile()){
    						 
    						 System.out.println("Logger report location"+loggerlocation);
    					 props.setProperty("log4j.appender.HTML.File",loggerlocation);
    				 LogManager.resetConfiguration();
    					PropertyConfigurator.configure(props);
    					 }
    					 else {
    						 System.out.println("File is present already");
    					 }
    			 log.info("Logger is initiated");
    			 
    			 
    			 }
    			 catch(Exception e) {
    			 System.err.println("Some error occured at Report Constructer"+e.getMessage());
    				 
    			 }	
	
    }


    public void reportInitilazation() {
		 try {
			 Date datea = new Date();  
		DateFormat format= new SimpleDateFormat("dd-mm-yyyy");
		
		
	String date=format.format(datea).toString();
		 String reportName="Execution_Result_"+date+".html";
		
		File file = new File (reportLocation.concat("\\".concat(reportName)));
		ReportLocationfinal=reportLocation.concat("\\".concat(reportName));
		if(file.exists()) {
			file.delete();
			
		}
		if(file.createNewFile()) {
			log.info("Report Location and name is "+reportName);
			
			Exreport= new ExtentReports(reportLocation.concat("\\".concat(reportName)),true);
			Exreport.addSystemInfo("Hostname", "Your System name");
			Exreport.addSystemInfo("Enviorement", "Enviorement name");
			Exreport.addSystemInfo("User Name is ", "Your  name");
			Exreport.loadConfig(new File(System.getProperty("user.dir")+"/src/report/extent-config.xml"));
			
		}
		else {
			System.out.println("Logger is already presnt can Show the results");
		}
		
		
		
		 }
		 catch(Exception e) {
			 System.err.println("Some Error occured at reportInitilazation methods"+e.getMessage());
			 
		 }
	 }

}
