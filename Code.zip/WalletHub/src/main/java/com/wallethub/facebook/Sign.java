package com.wallethub.facebook;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.wallethub.common.Base;



public class Sign extends Base{
	 Logger  log = Logger.getLogger(Sign.class); 
	public Sign(WebDriver driver){
		super(driver);
		
	}
	
	public String[]  facbookLogin(String UserName,String password,String URI){
		
		log.info("Inserting to--> Sign.facbookLogin() method");
		String []result =new String[2];
		try{
			webDriver.get(URI);
			log.info("Base URL is Opned  "+URI);
			Thread.sleep(4000);
			webElement=webDriver.findElement(By.xpath("*//input[@id='email']"));
			webElement.sendKeys(UserName);
			log.info("User id entered ");
			Thread.sleep(4000);
			webElement=webDriver.findElement(By.xpath(flipkartSignUpIn.getProperty("User_password")));
			webElement.sendKeys(password);
			log.info("password entered ");
			Thread.sleep(4000);
			webElement=webDriver.findElement(By.xpath(flipkartSignUpIn.getProperty("User_login")));
			webElement.submit();
			log.info("Clicked on Submit ");
			Thread.sleep(4000);
			result[0]=webDriver.getTitle();
			log.info(" After Click on Sign in page title "+webDriver.getTitle());
			webElement=webDriver.findElement(By.xpath("//a[@title='Profile']"));
			if (webElement.isDisplayed()){
				log.info(" Successfully Logged in and profile is dispalyed");
				result[1]="1";
				
			}
			else {
				result[1]="0";
				log.info("Not  Successfully Logged in and profile is not dispalyed");
			}
			
		}
		catch(Exception e){
			log.error("Some erorr occured at facbookLogin method"+e.getMessage());
			System.out.println("eror "+e.getMessage());
			result[0]=null;
			result[1]=null;
		}
	return result;
		
	}
	
	public String postStatus(String word){
		log.info("Inserting into--> postStatus methods");
		log.info("Posting data is "+word);
		String Result=null;
		try{
			webElement=webDriver.findElement(By.xpath(flipkartSignUpIn.getProperty("Enter_wordFirst")));
			webElement.isDisplayed();
			log.info("Write some thing is displayed ");
			webElement.click();
			Thread.sleep(4000);
			webElement=webDriver.findElement(By.xpath(flipkartSignUpIn.getProperty("Enter_word")));
			webElement.isDisplayed();
			log.info("Write some thing popup is displayed ");
			webElement.sendKeys(word);
			Thread.sleep(4000);
			webElement=webDriver.findElement(By.xpath(flipkartSignUpIn.getProperty("Enter_post")));
			webElement.isDisplayed();
			webElement.click();;
			Thread.sleep(10000);
			log.info("Clicked on  Post ");
			Result="1";
		}
		catch(Exception E){
			
		log.error("Some error occured at--> postStatus"+E.getMessage());
		Result=E.getMessage();
		
		}
		return Result;
	}
	

}
