package com.wallethub.profile;


import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;

import com.wallethub.common.Base;


public class ProfileCreation extends Base {
	 Logger  log = Logger.getLogger(ProfileCreation.class); 
	public ProfileCreation(WebDriver driver){
		super(driver);
		
	}
	
	
	public boolean  lightuserCreation(int rating,String Review,String url){
	
		
		log.info("Inserting into lightuserCreation methods");
	
		
		boolean status=false;
		try{
			webDriver.get(url);
			Thread.sleep(10000);
			log.info("Welleth hub page is opned");
		webElement=webDriver.findElement(By.xpath(walethubuser.getProperty("Chat_Box")));
		if (webElement.isDisplayed()){
			webElement.click();
			log.info("Chat box is closed ");
		}
		
		webElement=webDriver.findElement(By.xpath(walethubuser.getProperty("YourRating")));
		Actions mouseOver=new Actions(webDriver);
		mouseOver.moveToElement(webElement).perform();
		Thread.sleep(4000);
		log.info("Mouse over is successfully for your rating");
		webElement=webDriver.findElement(By.xpath(walethubuser.getProperty("SelectRating")));
		WebDriverWait expWait= new WebDriverWait(webDriver,100);
		expWait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(walethubuser.getProperty("SelectRating"))));
		log.info("rating is displayed and it is ready to click");
		Thread.sleep(4000);
		List<WebElement>ratings=webDriver.findElements(By.xpath(walethubuser.getProperty("selectedRating2")));
	for (WebElement el:ratings){
	String rate =	el.getText();
	if(rate.equals(Integer.toString(rating))){
		log.info("You tating selection is "+rate);
		el.click();
		log.info("rating is selected and clicked");
		break;
		
	}	
	}
	Thread.sleep(10000);
	String ReviewTitle=webDriver.getTitle();
	log.info("Sceond page title is "+ReviewTitle);
	if (ReviewTitle.equalsIgnoreCase("Reviews | Write Review")){
		log.info("Rating is  submited properly ");
		webElement=webDriver.findElement(By.xpath(walethubuser.getProperty("selectPolicy")));
	if(webElement.isDisplayed()){
		webElement.click();
		log.info("select Policy drop down is clicked");
		
	}
	
	webElement=webDriver.findElement(By.xpath(walethubuser.getProperty("selecte_health")));
	if(webElement.isDisplayed()){
		webElement.click();
		log.info("health is Selected ");
		
	}
		Thread.sleep(4000);
		webElement=webDriver.findElement(By.xpath(walethubuser.getProperty("overallRating")));
		webElement.click();
		log.info("Over alll rating is selected as good");
		Thread.sleep(4000);
		webElement=webDriver.findElement(By.xpath(walethubuser.getProperty("write_Review")));
		webElement.sendKeys(Review);
		log.info("Able to write review and your review comment is "+Review);
		webElement=webDriver.findElement(By.xpath(walethubuser.getProperty("submitReview")));
		webElement.submit();
		String 	loginTitle=webDriver.getTitle();
		if("Join WalletHub".equalsIgnoreCase(loginTitle)){
			status=true;
			log.info("Log in page is  opned  ");
		}
		else{
			status=false;
			log.info("Log in page is not opned  ");
		}
	}	
	else {
		log.info("Rating is not submited properly ");
		status=false;
	}
		}
		catch(Exception E){
			log.error("Some error occured at lightuserCreation "+E.getMessage());	
		}
		return status;
	}

public String logintoWalletHub(String UserID, String Password){
 String result="";

	try{
		Thread.sleep(4000);
	log.info("User id "+UserID);
	log.info("password is  "+Password);
	webElement=webDriver.findElement(By.xpath(walethubuser.getProperty("click_login")));
	if(webElement.isDisplayed()){	
		log.info("Log in option is displayed ");
		Actions over= new Actions(webDriver);
		over.moveToElement(webElement);
		Thread.sleep(1000);
		webElement.click();
	}
	Thread.sleep(4000);
	webElement=webDriver.findElement(By.xpath(walethubuser.getProperty("enter_login")));
	if(webElement.isEnabled()){
		log.info("User id is enable and u can enter");
		webElement.sendKeys(UserID);
	}
	Thread.sleep(4000);
	webElement=webDriver.findElement(By.xpath(walethubuser.getProperty("enter_password")));
	if(webElement.isEnabled()){
		log.info("enter_password is enable and u can enter");
		webElement.sendKeys(Password);
	}
	Thread.sleep(4000);
	webElement=webDriver.findElement(By.xpath(walethubuser.getProperty("click_login_submit")));
	if(webElement.isDisplayed()){
		log.info("Clicked in submit");
		webElement.submit();
	}
	Thread.sleep(4000);
	log.info("USer is is able to");
	result="Review  is posted ";
	}
	catch(Exception e){
		log.error("Some error occured at logintoWalletHub method"+e.getMessage());
		result="-1";
	}
	return result;
}

public boolean verfyReview(String username ,String data){
	boolean result=false;
	String reviewURl="https://wallethub.com/profile/"+username+"/reviews/";
	
	log.info("Post verify URL is "+reviewURl);
	try{
		Thread.sleep(1000);
		webDriver.get(reviewURl);
		webElement=webDriver.findElement(By.xpath(walethubuser.getProperty("confirem_review")));
		if(webElement.isDisplayed()){
			log.info("Review page is opened");
			String reviewData=webElement.getText();
			log.info("Your posted data from website is "+reviewData);
			if (data.contains(reviewData)){
				log.info("Your post data and web site data is equals");
				result=true;
				
			}
			else {
				log.info("Your post data and web site data is not equals");
				result=false;
			}
			
		}
		Thread.sleep(4000);
		
	
	}
	catch(Exception E){
		log.error("Some error occured at "+E.getMessage());
		result=false;
	}
	return result;
}

}
