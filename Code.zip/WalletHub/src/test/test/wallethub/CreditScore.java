package test.wallethub;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.wallethub.common.Configuration;
import com.wallethub.common.StartDriver;
import com.wallethub.profile.ProfileCreation;


public class CreditScore  extends StartDriver{
	CreditScore(){
		super();
	}
	 Logger  log = Logger.getLogger(CreditScore.class); 

@Test
@Parameters({"USERID","passwrod","url"})
 public void lightUser(String UsertID ,String Password,String URI ){
	
	String Review ="I am able to write review successfully by the autmation test script "
			+ "I am able to write review successfully by the autmation test script"
			+ "I am able to write review successfully by the autmation test script"
			+ "I am able to write review successfully by the autmation test script"
			+ "I am able to write review successfully by the autmation test script"
			+ "I am able to write review successfully by the autmation test script";
	int rating=5;
	
	Configuration.Test=Configuration.Exreport.startTest("verify light User creation");
	ProfileCreation profile = new ProfileCreation(super.webDriver);
	boolean result=profile.lightuserCreation(rating,Review,URI);
	
	if (result){
		 Configuration.Test.log(LogStatus.PASS, "Able to createuser");	
	}
	else {
		 Configuration.Test.log(LogStatus.FAIL, "Not able to createuser");
	}
	String logn=profile.logintoWalletHub(UsertID,Password);
	Configuration.Test.log(LogStatus.INFO, "User is logging in");
	if("Review  is posted ".equalsIgnoreCase(logn)){
		 Configuration.Test.log(LogStatus.PASS, "Able to Logged in and submit review ");	
	}
	else {
		 Configuration.Test.log(LogStatus.FAIL, "Able to not Logged in and submit review");	
	}
	
	boolean reviewVerification= profile.verfyReview(UsertID,Review);
if (reviewVerification){
	
	 Configuration.Test.log(LogStatus.PASS, "Input data and web review are same ");	
}
else {
	Configuration.Test.log(LogStatus.FAIL, "Input data and web review are not same ");	
}

    Configuration.Exreport.endTest(Configuration.Test);
 }



}
