package test.facebook;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.wallethub.common.Configuration;
import com.wallethub.common.StartDriver;
import com.wallethub.facebook.Sign;



public class SignInOut extends  StartDriver {
	 Logger  log = Logger.getLogger(SignInOut.class); 
	public SignInOut(){
		super();
	}
	
	@Test
	@Parameters({"username","passwrod","url2"})
	public void verifySignOut(String userName,String Password,String URI){
		Configuration.Test=Configuration.Exreport.startTest("verify FaceBook Sign In-Out");
		log.info("Your User Name is "+userName);
		log.info("Your password  is "+Password);
		Sign facebooklogin= new Sign(super.webDriver);
	    String rwesult[]=facebooklogin.facbookLogin(userName,Password,URI);
	    if ("1".equals(rwesult[1])){
	    	  Configuration.Test.log(LogStatus.PASS, "Able to Login"+rwesult[0]);
	    }
	    else {
	    	  Configuration.Test.log(LogStatus.FAIL, "Not Able to Login"+rwesult[0]);	
	    	
	    }
	    if ("1".equals(rwesult[1])){
	    	String status=facebooklogin.postStatus("Hello World");
	    	if("1".equals(status)){
	    		  Configuration.Test.log(LogStatus.PASS, "Able to Post status ");		
	    	}
	    	else {
	    		
	    		  Configuration.Test.log(LogStatus.FAIL, "Not Able to Post status "+status);	
	    	}
	    	
	    }
	    Configuration.Exreport.endTest(Configuration.Test);
		
		
	}
}
